<?php
	class Grading_Model extends CI_Model{
			function validateAccount(){
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$type=$this->input->post('type');
			$this->db->where('username',$username);
			$this->db->where('password',$password);
			if($type=='admin'){
			$query = $this->db->get('admin');
			}else if($type=='student'){
			$query = $this->db->get('student');
			}else{
			$query = $this->db->get('teacher');
			}
			if($query->num_rows() >0){
				$data=$query->row();
				$id=$data->id;
				$username=$data->username;
				$name=$data->fname.' '.$data->mname.' '.$data->lname;

		 		$session_data=array(
		 			'id'=>$id,
		 			'name'=>$name,
		 			'username'=>$username,
		 			'type'=>$type
		 			);
		 		$this->session->set_userdata($session_data);
            	return $query->result();
        }else return false;
		}

		function regStudent($data){
			$this->db->insert('student', $data);
			return $this->db->insert_id();

		}
		function regTeacher($data){
			$this->db->insert('teacher', $data);
			return $this->db->insert_id();

		}
		function addClass($data){
			$this->db->insert('class', $data);
			return $this->db->insert_id();
		}

		function addStudentClass($data){
			$result=$this->db->insert('student_class',$data);
			if($result){
				return true;
			}else return false;
		}
		function checkClassExist($t_id,$sc_id,$sb_id){
			$this->db->where('t_id',$t_id);
			$this->db->where('sc_id',$sc_id);
			$this->db->where('sb_id',$sb_id);
			$query=$this->db->get('class');
			if($query->num_rows()>0){
				return true;
			}else return false;	
		}

		function getTeachers(){
			$query=$this->db->get('teacher');
			if($query->num_rows()>0){
				return $query->result();
			}else {
				return false;
			}
		}

		function getSections(){
			$query=$this->db->get('section');
			if($query->num_rows()>0){
				return $query->result();
			}else {
				return false;
			}
		}

		function getSubjects(){
			$query=$this->db->get('subject');
			if($query->num_rows()>0){
				return $query->result();
			}else {
				return false;
			}
		}

		function getClasses(){
			$query=$this->db->get('class');
			if($query->num_rows()>0){
				return $query->result();
			}else {
				return false;
			}
		}


		function teacherClasses(){
								$this->db->select("*");
					     		$this->db->from('class');
					      		$this->db->join('teacher', 'teacher.id =class.t_id');
					      		$this->db->join('subject', 'subject.sb_id =class.sb_id');
					      		$this->db->join('section', 'section.sc_id =class.sc_id');
      		$this->db->where('teacher.id', $this->session->userdata('id'));
     		$query = $this->db->get();

		    if($query->num_rows() != 0){
		        return $query->result();
		    }
		    else{
		        return false;
		    }
				}

	}
?>