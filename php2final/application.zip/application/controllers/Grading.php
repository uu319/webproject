<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class Grading extends CI_Controller{
		function __construct(){
			parent::__construct();
			$this->load->model('Grading_Model', 'gm');
			$this->load->helper('form');
		}

		function index(){
			if($this->sessionCheck()==1){
				$this->v_aHome();
			}else if($this->sessionCheck()==2){
				$this->v_sHome();
			}else if($this->sessionCheck()==3){
				$this->v_tHome();
			}else{
				$this->load->view('layout/header');
				$this->load->view('index/index');
				$this->load->view('layout/footer');
			}
		}
/*-------------------------views-------------------------*/
		function v_aLogin(){
			if($this->sessionCheck()==1){
				$this->v_aHome2();
			}else if($this->sessionCheck()==2){
				$this->v_sHome2();
			}else if($this->sessionCheck()==3){
				$this->v_tHome2();
			}else{
			$this->load->view('layout/header');
			$this->load->view('login/adminlogin');
			$this->load->view('layout/footer');
			}
		}
		function v_sLogin(){
			if($this->sessionCheck()==1){
				$this->v_aHome();
			}else if($this->sessionCheck()==2){
				$this->v_sHome();
			}else if($this->sessionCheck()==3){
				$this->v_tHome();
			}else{
			$this->load->view('layout/header');
			$this->load->view('login/studentlogin');
			$this->load->view('layout/footer');
			}
		}
		function v_tLogin(){
			if($this->sessionCheck()==1){
				$this->v_aHome();
			}else if($this->sessionCheck()==2){
				$this->v_sHome();
			}else if($this->sessionCheck()==3){
				$this->v_tHome();
			}else{
			$this->load->view('layout/header');
			$this->load->view('login/teacherlogin');
			$this->load->view('layout/footer');
			}
		}
		function v_sReg(){
			if($this->sessionCheck()==1){
				$this->v_aHome();
			}else if($this->sessionCheck()==2){
				$this->v_sHome();
			}else if($this->sessionCheck()==3){
				$this->v_tHome();
			}else{
			$this->load->view('layout/header');
			$this->load->view('register/studentregister');
			$this->load->view('layout/footer');
			}
		}
		function v_tReg(){
			if($this->sessionCheck()==1){
				$this->v_aHome();
			}else if($this->sessionCheck()==2){
				$this->v_sHome();
			}else if($this->sessionCheck()==3){
				$this->v_tHome();
			}else{
			$this->load->view('layout/header');
			$this->load->view('register/teacherregister');
			$this->load->view('layout/footer');
			}
		}
		function v_aHome(){
			
			$this->load->view('layout/header');
			$this->load->view('home/adminhome');
			$this->load->view('layout/footer');
		}
		function v_sHome(){
			
			$this->load->view('layout/header');
			$this->load->view('home/studenthome');
			$this->load->view('layout/footer');
		}
		function v_tHome(){
			
			$this->load->view('layout/header');
			$this->load->view('home/teacherhome');
			$this->load->view('layout/footer');
		}
		function v_addClass(){
			$this->load->view('layout/header');
			$this->load->view('add/adminadd');
			$this->load->view('layout/footer');
		}

		function v_tLoad(){
			$this->load->view('layout/header');
			$this->load->view('displays/teacherload');
			$this->load->view('layout/footer');
		}

		function v_adminView(){
			$this->load->view('layout/header');
			$this->load->view('displays/adminView');
			$this->load->view('layout/footer');
		}

/*-------------------------views-------------------------*/		

/*-------------------------checks-------------------------*/
		function sessionCheck(){
	 	if($this->session->userdata('username')!=''){
	 		if($this->session->userdata('type')=='admin'){
	 		return 1;
	 		}else if($this->session->userdata('type')=='student'){
	 		return 2;
	 		}if($this->session->userdata('type')=='teacher'){
	 		return 3;
	 		}
	 	}else{
	 		return 4;
	 		}

	 	}
	 	function logout(){
	 		$this->session->unset_userdata('username');
	 	redirect(base_url('grading'));	
	 	}
	 
		function validateAccount(){
			$result=$this->gm->validateAccount();
			$msg['success']=false;
			if($result!=false){
				$msg['success']=true;
				
			}
			echo json_encode($msg);
		}
/*-------------------------checks-------------------------*/		

/*-------------------------insert-------------------------*/	
        function regStudent(){
                $config['upload_path']= './assets/uploads';
                $config['allowed_types']= 'jpeg|png|jpg';
              	
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')){
                        $error = array('error' => $this->upload->display_errors());              
                }
                else{
                        $data = array('upload_data' => $this->upload->data());
                        $personsData = array(
                            'fname'=>$this->input->post('fname'),
                            'mname'=>$this->input->post('mname'),
                            'lname'=>$this->input->post('lname'),
                            'sc_id'=>$this->input->post('sc_id'),
                            'username'=>$this->input->post('username'),
                            'password'=>$this->input->post('password'),
                            'picname'=>$data['upload_data']['file_name']
                        );
                        $this->gm->regStudent($personsData);
                       echo json_encode($personsData);
                }
        }

        function regTeacher(){
                $config['upload_path']= './assets/uploads';
                $config['allowed_types']= 'jpeg|png|jpg';
              	
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')){
                        $error = array('error' => $this->upload->display_errors());
                }
                else{
                        $data = array('upload_data' => $this->upload->data());
                        $personsData = array(
                            'fname'=>$this->input->post('fname'),
                            'mname'=>$this->input->post('mname'),
                            'lname'=>$this->input->post('lname'),
                            'username'=>$this->input->post('username'),
                            'password'=>$this->input->post('password'),
                            'picname'=>$data['upload_data']['file_name']
                        );
                       $this->gm->regTeacher($personsData);
                       echo json_encode($personsData);
                }            
        }   

        function addClass(){
        	$msg['success']=false;
        	$t_id=$this->input->post('t_id');
        	$sc_id=$this->input->post('sc_id');
        	$sb_id=$this->input->post('sb_id');
        	$data=array(
        		't_id'=>$t_id,
        		'sc_id'=>$sc_id,
        		'sb_id'=>$sb_id
        		);
        	$check=$this->gm->checkClassExist($t_id,$sc_id,$sb_id);
        	if($check){
        		$msg[1]['success']=false;
        		$msg[1]['message']="Class Already Exist";
        	}else{
	        	$result=$this->gm->addClass($data);
	        	if($result){
	        		$msg[1]['success']=true;
	        	}
        	}
        	echo json_encode($msg);
        }

        function addStudentClass(){
        	$c_id=$this->input->post('c_id');
        	$st_id=$this->input->post('st_id');
        	$msg['success']=false;
        	$msg['message']='Error';
        	$data=array(
        		'c_id'=>$c_id,
        		'st_id'=>$st_id
        		);
        	$result=$this->gm->addStudentClass($data);
        	if($result){
        		$msg['success']=true;
        		$msg['message']='Success';
        	}
        	echo json_encode($msg);
        }
       
						
/*-------------------------checks-------------------------*/	


		function getTeachers(){
			$result= $this->gm->getTeachers();
			echo json_encode($result);
		}	

		function getSections(){
			$result= $this->gm->getSections();
			echo json_encode($result);
		}	

		function getSubjects(){
			$result= $this->gm->getSubjects();
			echo json_encode($result);
		}
		function teacherClasses(){
			$result= $this->gm->teacherClasses();

			echo json_encode($result);
		}	


	}

?>