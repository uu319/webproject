<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <script src="assets/js/jquery.js"></script>
  <script src="assets/js.bootstrap.min.js"></script>
</head>
<body style="background-color: #808080;">
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                        <a class="navbar-brand text-light" href="#">Admin View</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNavDropdown">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Options
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="#">Logout</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                </nav>

    <div class="container">
        <div class="row">
            <div class="col-lg-2"></div>
            <div class="col-lg-8">
                <div class="jumbotron" style="margin-top:120px;">
                     <form>
                        <h4>Teachers List</h4>
                        <table class="table table-striped">
                            <thead class="thead-dark">
                                <tr>
                                <th scope="col">Teacher ID</th>
                                <th scope="col">Section ID</th>
                                <th scope="col">Subject ID</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <th scope="row">123</th>
                                <td>123</td>
                                <td>123</td>
                                </tr>
                                <tr>
                                <th scope="row">321</th>
                                <td>321</td>
                                <td>321</td>
                                </tr>
                            </tbody>
                            </table>
                        <a href="adminhome.php">Back</a>
                    </form> 
                </div> 
            </div>
            <div class="col-lg-2"></div>
        </div>
    </div>  
</body>
</html>