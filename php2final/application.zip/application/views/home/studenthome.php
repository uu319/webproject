                <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                        <a class="navbar-brand text-light" href="#">Student Home</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNavDropdown">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Options
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="studentlogin.php">Logout</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                </nav>
 <h1 >Welcome <?php echo $this->session->userdata['name']?></h1>
    <div class="container">
        <div class="row">
            <div class="col-lg-2"></div>
            <div class="col-lg-8">
                <div class="jumbotron" style="margin-top:120px;">
                     <form>
                        <h4>Your Grades</h4>
                        <table class="table table-striped">
                            <thead class="thead-dark">
                                <tr>
                                <th scope="col">Subject</th>
                                <th scope="col">Midterm</th>
                                <th scope="col">Finals</th>
                                <th scope="col">Average</th>
                                <th scope="col">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <th scope="row">Math</th>
                                <td>85</td>
                                <td>85</td>
                                <td>85</td>
                                <td>Passed</td>
                                </tr>
                                <tr>
                                <th scope="row">English</th>
                                <td>75</td>
                                <td>75</td>
                                <td>75</td>
                                <td>Failed</td>
                                </tr>
                            </tbody>
                            </table>
                    </form> 
                </div> 
            </div>
            <div class="col-lg-2"></div>
        </div>
    </div>  
