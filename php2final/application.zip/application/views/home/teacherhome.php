                <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                        <a class="navbar-brand text-light" href="#">Teacher Home</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNavDropdown">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Options
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="teacherlogin.php">Logout</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                </nav>
 <h1 >Welcome <?php echo $this->session->userdata['name']?></h1>
    <div class="container">
        <div class="row">
            <div class="col-lg-2"></div>
            <div class="col-lg-8">
                <div class="jumbotron" style="margin-top:120px;">
                <table class="table">
                    <p class="h3">Teacher Load</p>
                    <thead>
                         <th>Class ID</th>
                        <th>Section Name</th>
                        <th>Subject Name</th>
                         <th>Action</th>

                    </thead>
                    <tbody  id="showdata">
                           
                    </tbody>
                </table>
                    
                </div> 
            </div>
            <div class="col-lg-2"></div>
        </div>
    </div>

  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Add Student</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form id="loginForm" method="post"> 
                        <div class="alert alert-danger" style="display: none">
                            <strong>Success!</strong> Indicates a successful or positive action.
                     </div>
                        <div>
                       <!-- <img src=" alt="Avatar" style="width:50%; margin-left:25%; margin-top:2px; margin-bottom:3px;">-->
                        </div>
                        <form id="form" method="post">
                        <input type="text" id="c_id" name="c_id">
                        <div class="form-group">
                              <input type="text" class="form-control" placeholder="Enter Email" name="st_id"; id="st_id">
                        </div>
                       </form>
                        <button type="button" class="btn btn-dark form-control" id="confirm">Confirm</button>
       </form>
      </div>
      
    </div>
  </div>
</div>
     <script>
      $('#showdata').on('click', '.item-select', function(){
               $('#myModal').modal('show');
               var c_id=$(this).attr('data');
               $('input[name=c_id]').val(c_id);
            });

      $('#confirm').click(function(){
            
            
            $.ajax({
                    data:{'sc_id':1, 'c_id':2},
                    method:'post',
                    type:'ajax',
                    url:'<?php echo base_url('grading/addStudentClass')?>',
                    dataType:'json',
                    success:function(){
                        alert('sample');
                    },
                    error:function(){}

               });

      });

      $.ajax({
                method:'post',
                type:'ajax',
                url:'<?php echo base_url('grading/teacherClasses')?>',
                async: false,
                dataType: 'json',
                success: function(data){
                    var html='';
                    var i;
                    
                    for(i=0; i < data.length; i++){
                        html+='<tr>'+
                                '<td>'+data[i].c_id+'</td>'+
                                '<td>'+data[i].sc_name+'</td>'+

                                '<td>'+data[i].sb_name+'</td>'+
                               
                                '<td>'+
                                    '<a href="javascript:;" class="btn btn-outline-dark item-select" data="'+data[i].c_id+'">Add Student</a>'+
                                '</td>'+
                            '</tr>';
                    }
                    $('#showdata').html(html);
                },
                error: function(){
                    alert('Could not load');
                }
            });
    </script>  
