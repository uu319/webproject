
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                        <a class="navbar-brand text-light" href="#">Admin Home</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarNavDropdown">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Options
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="index.php">Logout</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                </nav>
                <h1 >Welcome <?php echo $this->session->userdata['name']?></h1>

    <div class="container">
        <div class="row">
            <div class="col-lg-4"></div>
            <div class="col-lg-4">
                <div class="jumbotron" style="margin-top:120px;">
                     <form>
                        <h3>What do you want?</h3>
                     <a href="<?php echo base_url('grading/v_addClass')?>" type="submit" class="btn btn-outline-dark form-control">Add Class</a>
                     <a href="<?php echo base_url('grading/v_adminView')?>" type="submit" class="btn btn-outline-dark form-control">View Classes</a>
                    </form> 
                </div> 
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>  
